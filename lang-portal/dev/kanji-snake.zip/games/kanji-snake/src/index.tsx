import React from 'react';
import { GameProps } from '@lang-portal/shared/types';
import Phaser from 'phaser';
import { GroupSelectScene } from './scenes/GroupSelectScene';
import { GameScene } from './scenes/GameScene';

const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO,
  width: 1200,
  height: 900,
  backgroundColor: '#1a1a1a',
  parent: 'game',
  scene: [GroupSelectScene, GameScene],
  physics: {
    default: 'arcade',
    arcade: {
      debug: false
    }
  }
};

export function KanjiSnake({ apiClient, sessionId, onGameComplete }: GameProps) {
  const gameRef = React.useRef<Phaser.Game | null>(null);

  React.useEffect(() => {
    if (gameRef.current) return;

    // Create game instance
    gameRef.current = new Phaser.Game({
      ...config,
      parent: 'game-container'
    });

    // Cleanup on unmount
    return () => {
      if (gameRef.current) {
        gameRef.current.destroy(true);
        gameRef.current = null;
      }
    };
  }, []);

  return (
    <div 
      id="game-container"
      style={{ 
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        backgroundColor: '#f1f5f9',
        padding: '20px'
      }}
    />
  );
}

// For development mode
if (typeof window !== 'undefined' && import.meta.env.DEV) {
  const container = document.getElementById('game');
  if (container) {
    new Phaser.Game({ ...config, parent: container });
  }
}

export default KanjiSnake; 