import axios from 'axios';
import { wordService } from './WordService';

interface Session {
  id: number;
  group_id: number | null;
  activity_id: number;
  created_at: string;
}

interface SessionResponse {
  data: Session;
  error: string | null;
}

export class SessionService {
  private currentSession: Session | null = null;
  private readonly API_BASE = '/api';
  private readonly ACTIVITY_ID = 2; // Kanji Snake game activity ID

  async startSession(): Promise<boolean> {
    console.log('Starting new session...');
    const groupId = wordService.getCurrentGroupId();
    if (groupId === undefined) {
      console.error('No group selected');
      return false;
    }

    try {
      const sessionData = {
        activity_id: this.ACTIVITY_ID,
        group_id: groupId === -1 ? null : groupId
      };

      console.log('Creating session with:', sessionData);
      const response = await axios.post<SessionResponse>(`${this.API_BASE}/sessions`, sessionData);

      console.log('Session created:', response.data);
      this.currentSession = response.data.data;
      return true;
    } catch (error) {
      console.error('Error creating session:', error);
      if (axios.isAxiosError(error)) {
        console.error('Response:', error.response?.data);
        console.error('Status:', error.response?.status);
      }
      return false;
    }
  }

  async submitWordReview(wordId: number, correct: boolean): Promise<boolean> {
    console.log('Submitting word review:', { wordId, correct });
    if (!this.currentSession) {
      console.error('No active session');
      return false;
    }

    try {
      console.log('Sending review to API...');
      await axios.post(`${this.API_BASE}/sessions/${this.currentSession.id}/review`, {
        word_id: wordId,
        correct: correct
      });
      console.log('Review submitted successfully');
      return true;
    } catch (error) {
      console.error('Error submitting word review:', error);
      if (axios.isAxiosError(error)) {
        console.error('Response:', error.response?.data);
        console.error('Status:', error.response?.status);
      }
      return false;
    }
  }

  getCurrentSession(): Session | null {
    return this.currentSession;
  }

  endSession(): void {
    console.log('Ending session');
    this.currentSession = null;
  }
}

export const sessionService = new SessionService(); 