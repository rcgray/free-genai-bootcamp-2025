import React from 'react';
import ReactDOM from 'react-dom/client';
import { KanjiSnake } from './index';
import './dev.css';

ReactDOM.createRoot(document.getElementById('game')!).render(
  <React.StrictMode>
    <KanjiSnake 
      apiClient={{} as any}
      sessionId={undefined}
      onGameComplete={() => console.log('Game complete')}
    />
  </React.StrictMode>
); 